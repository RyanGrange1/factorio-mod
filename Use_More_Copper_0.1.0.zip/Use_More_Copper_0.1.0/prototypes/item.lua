data:extend(
{
	{--Copper wall
 
		type = "item",
		name = "copper-wall",
		icon = "__ryans_mod__/graphics/icons/copper-wall.png",
		flags = {"goes-to-main-inventory"},
		subgroup = "defensive-structure",
		order = "a[stone-wall]-c[opper-wall]",
		place_result = "copper-wall",
		stack_size = 100
    },
}
)