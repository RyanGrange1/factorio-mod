data:extend({
  {
    type = "recipe",
    name = "copper-wall",
	energy_required = 2,
    enabled = false,
    ingredients = 
	{
	   {"copper-plate", 15},
	   {"stone-wall", 1}
	},
    result = "copper-wall",
    requester_paste_multiplier = 10
  },
  })
