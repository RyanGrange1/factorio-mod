data:extend(
{
	{--Copper Wall
 
		type = "item",
		name = "copper-wall",
		icon = "__ryans_mod__/graphics/icons/copper-wall.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "defensive-structure",
		order = "a[stone-wall]-c[copper-wall]",
		place_result = "copper-wall",
		stack_size = 100
	},
}
)
